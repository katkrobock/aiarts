let video;
let yolo;
let status;
let objects = [];
let pg;

function setup() {
  createCanvas(640, 360); 
  pg = createGraphics(640, 360);
  video = createVideo(['greenspace.mov'], videoLoad);
  video.size(640, 360);

  // Create a YOLO method
  yolo = ml5.YOLO(video, startDetecting);

  // Hide the original video
  video.hide();
  status = select('#status');
  
  // People = objects that are labeled 'person'
//  people = objects[i].person;
}

function videoLoad() {
  video.loop();
  video.volume(0);
}

function draw() {
  let thenumberfortestingimages=0;
  image(video, 0, 0, width, height);
  for (let i = 0; i < objects.length; i++) {
    // noStroke();
    // fill(0, 255, 0);
    // text(objects[i].className, objects[i].x * width, objects[i].y * height - 5);
    // noFill();
    // strokeWeight(1);
    // stroke(0, 255, 0);
    // rect(objects[i].x * width, objects[i].y * height, objects[i].w * width, objects[i].h * height);
    if(millis()>5000 && objects[i].className == "person") {
      console.log("dew it");
      save(get(objects[i].x * width, objects[i].y * height, objects[i].w * width, objects[i].h * height), "test"+thenumberfortestingimages+".png"); thenumberfortestingimages++;
        noLoop(); //delay(1000);
    }
  }
}

function startDetecting() {
  status.html('Model loaded!');
  detect();
}

function detect() {
  yolo.detect(function(err, results) {
    objects = results;
    detect();
  });
}

//function keyPressed() {
//  if (keyCode === ENTER) {
//    objects.save('i-think-this-is-a-person', 'png');
//  }
//}

// function keyPressed(){
//  let c = createGraphics(100,100);
// if (keyCode === ENTER){
// save(c, 'test.jpg');
// }
// }